Assignment1
1. Install MS SQL Server
Sol. Step1: Open any browser and searched for Ms sql Server download.
Step2: Downloaded Developer version.
...............................


2.Give the difference between Char and Varchar data type.
Sol Char:1. Its used to store characters strings of fixed length.
Varchar:  Its used to store characters strings of variable length.
(3-4 steps).

3.Explain the types of SQL Commands.
Sol. There are 5 Types of Sql commands:
1 DDL: DATA DEFINATION LANGUAGE:
1 CREATE: USED TO CREATE DATABASES AND TABLES�
2 ALTER:
3 TRUNCATE:
4.DROP: 
2 DML: 
3 DQL:
5.DCL:
6.TCL:
�.���.


4.Explain NVarchar and Nchar.
SOL. Nchar and Nvarchar data types are the unicode data type is a universal character encoding language which accepts english and also other languages.
Nchar:

Nvarchar:
(3-4 points)


Transaction:

Begin transaction;
Update �..
Insert
Delete
Commit

Category which has total amount greater than 500.
Select category,sum(amount) as s from sales group by category having sum(amount)>500.
