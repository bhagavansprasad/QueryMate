from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("sum", views.addtion, name="add"),
    path("diff", views.difference, name="diff"),
    path("prod", views.product, name="prod"),
    path("div", views.division, name="div"),
    path("calc", views.calucation, name="calculations"),
    path("result", views.submit_cal, name="result")
]