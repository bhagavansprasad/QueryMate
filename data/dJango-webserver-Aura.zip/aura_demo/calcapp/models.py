from django.db import models

class Movies(models.Model):
    theatre_name = models.CharField(max_length=100)
    movie = models.CharField(max_length=100)