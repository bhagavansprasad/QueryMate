#### Sample Django Web server (Calculator) with 4 REST APIs.
##### Provides you REST APIs
    add, diff, prod, div,caliculations

##### Environment
    Linux, Django, Python3
    
##### How to run?
```shell
python manage.py runserver 172.27.111.53:8888
```

##### How to access via browser?
    http://172.27.111.53:8888/calcapp/
    http://172.27.111.53:8888/calcapp/calc
    http://172.27.111.53:8888/calcapp/sum
    http://172.27.111.53:8888/calcapp/diff
    http://172.27.111.53:8888/calcapp/prod

##### How to Get the page via Curl?
```shell
curl http://172.27.111.53:8888/calcapp/cal
```

##### How to post request (To Add 20 40)
```shell
curl -X POST http://172.27.111.53:8888/calcapp/result \
    -d "num1=20&num2=40&cal=add" 
```
    
##### Source tree
```Information
    .
    ├── aura_demo
    │   ├── __init__.py
    │   ├── asgi.py
    │   ├── settings.py
    │   ├── urls.py
    │   └── wsgi.py
    ├── calcapp
    │   ├── __init__.py
    │   ├── admin.py
    │   ├── apps.py
    │   ├── migrations
    │   │   ├── 0001_initial.py
    │   │   └── __init__.py
    │   ├── models.py
    │   ├── templates
    │   │   ├── calculation.html
    │   │   ├── home_page.html
    │   │   └── result.html
    │   ├── tests.py
    │   ├── urls.py
    │   └── views.py
    ├── db.sqlite3
    ├── manage.py
    ├── notes.md
    └── notes.txt

python manage.py runserver 172.27.111.53:8000
```