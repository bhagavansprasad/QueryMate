from django.shortcuts import render, HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json

def home(request):
    return HttpResponse("Hello Aura: Base function")

def addtion(request):
    return HttpResponse("Hello Aura: Add function")

def difference(request):
    return HttpResponse("Hello Aura: diff function")

def product(request):
    return HttpResponse("Hello Aura: prod function")

def division(request):
    return HttpResponse("Hello Aura: div function")

def calucation(request):
    return render(request, 'calculation.html')

@csrf_exempt
def submit_cal(request):
    print(request.POST['num1'])
    print(request.POST['num2'])
    result = 0
    if request.POST.get('cal') == "add":
        result = int(request.POST['num1']) + int(request.POST['num2'])
    elif request.POST.get('cal') == "mul":
        result = int(request.POST['num1']) * int(request.POST['num2'])
    elif request.POST.get('cal') == "sub":
        result = int(request.POST['num1']) - int(request.POST['num2'])
    elif request.POST.get('cal') == "div":
        result = int(request.POST['num1']) / int(request.POST['num2'])
    print(f"result :{result}")
    # return render(request, 'result.html', {"result": result})
    return HttpResponse(json.dumps({"result": result}), content_type="application/json")

